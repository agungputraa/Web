<?php require_once("login.php");

session_start();
header("Location: login.php");
?>
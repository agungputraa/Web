<?php
require_once("koneksi.php");
$id = $_GET['Id'];
$sql = "DELETE FROM user WHERE id='$id'";
$result = mysqli_query ($conn, $sql);
if ($result){
    echo "<script>alert('Akun Berhasil Di Hapus');
    </script>";
    header('Refresh: 1; login.php');
   }else{
    echo "data tidak berhasil di hapus";
   }
?>